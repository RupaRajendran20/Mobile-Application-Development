package assignment5.ruparajendran.newsgateway;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.newsgateway.R;

import java.util.Locale;

public class ArticleFragment extends Fragment {

    private static final String TAG = "ArticleFragment";

    public ArticleFragment(){}

    static ArticleFragment newInstance(Article country, int index, int max)
    {
        ArticleFragment f = new ArticleFragment();
        Bundle bdl = new Bundle(1);
        bdl.putSerializable("ARTICLE_DATA", country);
        bdl.putSerializable("INDEX", index);
        bdl.putSerializable("TOTAL_COUNT", max);
        f.setArguments(bdl);
        Log.d(TAG, "newInstance: ss"+country.getUrltoImage());
        return f;

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View fragment_layout = inflater.inflate(R.layout.fragment_article, container, false);

        Bundle args = getArguments();
        if (args != null)
        {
            final Article temp = (Article) args.getSerializable("ARTICLE_DATA");

            if (temp == null)
            {
                return null;
            }
            int index = args.getInt("INDEX");
            int total = args.getInt("TOTAL_COUNT");

            if(temp.getUrl() != null)
                shareStory(fragment_layout,temp.getUrl());

            if(!isNull(temp.getTitle()))
            {
                TextView title = fragment_layout.findViewById(R.id.title);
                title.setText(temp.getTitle());
                title.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        if(temp.getUrl() != null)
                            openStory(temp.getUrl());
                    }
                });
            }
            else
            {
                TextView title = fragment_layout.findViewById(R.id.title);
                title.setText("No Title");
                title.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        if(temp.getUrl() != null)
                            openStory(temp.getUrl());
                    }
                });
            }


            if(!isNull(temp.getAuthor()))
            {
                TextView author = fragment_layout.findViewById(R.id.author);
                author.setText(temp.getAuthor());
            }

            if(!isNull(temp.getPublishedAt()))
            {
                TextView publishedAt = fragment_layout.findViewById(R.id.publishedAt);
                publishedAt.setText(temp.getPublishedAt());
            }

            if(!isNull(temp.getDescription()))
            {
                TextView desc = fragment_layout.findViewById(R.id.description);
                desc.setText(temp.getDescription());

                desc.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        if(temp.getUrl() != null)
                            openStory(temp.getUrl());
                    }
                });
            }
            //Log.d(TAG, "onCreateView: ohsi"+temp.getUrltoImage());
            if(temp.getUrltoImage().equals(""))
            {

                ImageView picture = fragment_layout.findViewById(R.id.image);
                picture.setBackgroundResource(R.drawable.placeholder);

                picture.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        if(temp.getUrl() != null)
                            openStory(temp.getUrl());
                    }
                });

            }
            else
            {
                Log.d(TAG, "onCreateView: "+temp.getUrltoImage());
                ImageView picture = fragment_layout.findViewById(R.id.image);
                    Glide.with(this)
                            .load(temp.getUrltoImage())
                            .placeholder(R.drawable.loading)
                            .error(R.drawable.error)
                            .into(picture);
                Log.d(TAG, "onCreateView: " + temp.getUrltoImage());
//                Picasso.get().load(temp.getUrltoImage()).fit()
//                        .networkPolicy(NetworkPolicy.NO_CACHE)
//                        .memoryPolicy(MemoryPolicy.NO_CACHE)
//                        .error(R.drawable.error)
//                        .placeholder(R.drawable.placeholder)
//                        .into(picture); // Use this if you don't want a callback

                picture.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        if(temp.getUrl() != null)
                            openStory(temp.getUrl());
                    }
                });
            }

            TextView pageNum = fragment_layout.findViewById(R.id.pageNo);
            pageNum.setText(String.format(Locale.US, "%d of %d", index, total));

            return fragment_layout;
        }
        else
            return null;
    }

    private boolean isNull(String data)
    {
        if(data == null || data.equals("null"))
            return true;
        else
            return false;
    }

    private void shareStory(View v, final String URL)
    {
        ImageButton btn = v.findViewById(R.id.share);
        btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = getString(R.string.share_header) + URL;
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, getString(R.string.app_name));
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share via"));
            }
        });
    }

    public void printArticle(Article a)          // for testing purpose
    {
        Log.d(TAG, "printLst: bp: =========================================================================================================");
        Log.d(TAG, "printLst: bp: Title:" + a.getTitle());
        Log.d(TAG, "printLst: bp: Author:" + a.getAuthor());
        Log.d(TAG, "printLst: bp: Published on:" + a.getPublishedAt());
        Log.d(TAG, "printLst: bp: URL:" + a.getUrl());
        Log.d(TAG, "printLst: bp: Image URL:" + a.getUrltoImage());
        Log.d(TAG, "printLst: bp: Desc:" + a.getDescription());
        Log.d(TAG, "printLst: bp:---------------------------------------------");

        Log.d(TAG, "printLst: bp: =========================================================================================================");
    }

    private void openStory(String URL)
    {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(URL));
        startActivity(i);
    }


}

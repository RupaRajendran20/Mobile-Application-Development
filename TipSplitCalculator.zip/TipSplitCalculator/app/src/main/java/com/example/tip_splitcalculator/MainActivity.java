package com.example.tip_splitcalculator;

import androidx.appcompat.app.AppCompatActivity;
import org.w3c.dom.Text;
import androidx.annotation.NonNull;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.app.Activity;
import java.math.RoundingMode;
import java.text.DecimalFormat;

//public class MainActivity extends Activity
// {
  //  @Override
    //public void onCreate(Bundle savedInstanceState)
// {
      //  super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
    //}
//}

    public class MainActivity extends AppCompatActivity
    {
        private EditText totalBill;
        private EditText no_of_persons;
        private TextView tip;
        private TextView total;
        private TextView bill;
        private TextView rem;

        private static final String TAG = "MainActivity";
        // try {
        //warningText.setText("");
        //double amount = Double.parseDouble(enterAmountInput.getText().toString());
        //double tip = Double.parseDouble(enterTipInput.getText().toString()) * 0.01;
        //double tipAmount = tip * amount;
        //String tipAmountString = "$" + String.format("%.2f",tipAmount);
        //tipAmountOutput.setText(tipAmountString);
        //double amountDue = amount + tipAmount;
        //String amountDueString = "$" + String.format("%.2f",amountDue);
        //amountDueOutput.setText(amountDueString);
         // }
              //  catch(Exception e){
        //ArrayList<String> msgs = new ArrayList<String>();
        //String msg = "Error: Enter items properly";
        //warningText.setText(msg);

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            totalBill = findViewById(R.id.enterBillAmount);
            no_of_persons = findViewById(R.id.numberOfPeople);
            total = findViewById(R.id.totalBillWithTip);
            tip = findViewById(R.id.tipAmount);
            bill = findViewById(R.id.costPerPerson);
            rem = findViewById(R.id.remainder);
        }

        public void calculateTipAmount(View v) {
            Log.d(TAG, "calculateTipAmount: ");
            String bill = totalBill.getText().toString();
            if (bill.trim().isEmpty())
            {
                ((RadioButton) findViewById(R.id.select12PercentTip)).setChecked(false);
                ((RadioButton) findViewById(R.id.select15PercentTip)).setChecked(false);
                ((RadioButton) findViewById(R.id.select18PercentTip)).setChecked(false);
                ((RadioButton) findViewById(R.id.select20PercentTip)).setChecked(false);
                tip.setText("");
                total.setText("");
            } else
                {
                double billAmount=Double.parseDouble(bill);
                double tipvalue = 0;
                if (v.getId() == R.id.select12PercentTip)
                {
                    tipvalue = percentageAmount(billAmount, 12);
                    DecimalFormat df = new DecimalFormat("0.00");
                    tipvalue= Double.parseDouble(df.format(tipvalue));
                } else if (v.getId() == R.id.select15PercentTip)
                {

                    tipvalue = percentageAmount(billAmount, 15);
                    DecimalFormat df = new DecimalFormat("0.00");
                    tipvalue= Double.parseDouble(df.format(tipvalue));
                } else if (v.getId() == R.id.select18PercentTip)
                {
                    tipvalue = percentageAmount(billAmount, 18);
                    DecimalFormat df = new DecimalFormat("0.00");
                    tipvalue= Double.parseDouble(df.format(tipvalue));
                } else if (v.getId() == R.id.select20PercentTip)
                {
                    tipvalue = percentageAmount(billAmount, 20);
                    DecimalFormat df = new DecimalFormat("0.00");
                    tipvalue= Double.parseDouble(df.format(tipvalue));
                }
                tip.setText(Double.toString(tipvalue));


                total.setText(Double.toString((tipvalue + billAmount)));
                DecimalFormat df = new DecimalFormat("0.00");



            }
        }

        public void calculateSplitOverage(View v)
        {
            Log.d(TAG, "calculateSplitOverage: ");
            DecimalFormat df = new DecimalFormat("0.00");
            df.setRoundingMode(RoundingMode.UP);
            double bill1 = Double.parseDouble(total.getText().toString());
            int peopleCount = Integer.parseInt(no_of_persons.getText().toString());
            double amountCalc = Double.parseDouble(df.format(bill1 / peopleCount));
            bill.setText(Double.toString(amountCalc));
            df.setRoundingMode(RoundingMode.HALF_EVEN);
            int numberofPeople = Integer.parseInt(no_of_persons.getText().toString());
            double textTemp = (amountCalc * 5) - bill1;
            rem.setText(df.format((amountCalc * numberofPeople) - bill1));
        }

        public void clearAll(View v)
        {
            Log.d(TAG, "clearAll: ");
            totalBill.setText("");
            total.setText("");
            no_of_persons.setText("");
            tip.setText("");
            bill.setText("");
            rem.setText("");
            ;
            ((RadioButton) findViewById(R.id.select12PercentTip)).setChecked(false);
            ((RadioButton) findViewById(R.id.select15PercentTip)).setChecked(false);
            ((RadioButton) findViewById(R.id.select18PercentTip)).setChecked(false);
            ((RadioButton) findViewById(R.id.select20PercentTip)).setChecked(false);
        }

        public double percentageAmount(double value, double percentage)
        {
            return (value * percentage) / 100;
        }

        @Override
        protected void onSaveInstanceState(@NonNull Bundle outState)
        {
            outState.putString("totalBillWithoutTip", totalBill.getText().toString());
            String temp = "$";
            String finalString = temp + tip.getText().toString();
            outState.putString("tipAmount", tip.getText().toString());
            outState.putString("totalBillWithTip", total.getText().toString());
            String finalString1 = temp + total.getText().toString();
            outState.putString("billPerPerson", bill.getText().toString());
            String finalString2 = temp + bill.getText().toString();
            outState.putString("overage", rem.getText().toString());
            String finalString3 = temp + rem.getText().toString();
            super.onSaveInstanceState(outState);
        }

        @Override
        protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState)
        {
            super.onRestoreInstanceState(savedInstanceState);
            totalBill.setText(savedInstanceState.getString("totalBillWithoutTip"));
            tip.setText(savedInstanceState.getString("tipAmount"));
            total.setText(savedInstanceState.getString("totalBillWithTip"));
            bill.setText(savedInstanceState.getString("billPerPerson"));
            rem.setText(savedInstanceState.getString("overage"));
        }
    }
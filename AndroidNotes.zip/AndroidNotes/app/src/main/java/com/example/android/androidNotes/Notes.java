package com.example.android.androidNotes;

import java.io.Serializable;
import java.util.Date;

public class Notes implements Comparable<Notes>, Serializable {

    private String title;
    private String description;
    private Date updatedTime;

    Notes()
    {}
    

    public Notes(String title, String description, Date lastUpdatedTime)
    {
        this.title = title;
        this.description = description;
        this.updatedTime = lastUpdatedTime;

    }

    public void setNoteTitle(String title)
    {
        this.title = title;
    }

    public String getNoteTitle()
    {
        return title;
    }

    public void setNoteDescription(String description)
    {
       this.description = description;
    }

    public String getNoteDescription()
    {
        return description;
    }

    public Date getupdatedTime() {
        return updatedTime;
    }

    public void setLastUpdatedTime(Date lastUpdatedTime) {
        this.updatedTime = lastUpdatedTime;
    }


    public String toString()
    {
        return "Title=" + title + ", Description=" + description + ", lastUpdatedTime=" + updatedTime;
    }

    @Override
    public int compareTo(Notes notes) {
        if (notes == null || getupdatedTime() == null || notes.getupdatedTime() == null) {
            return 0;
        }
        return notes.getupdatedTime().compareTo(this.updatedTime);
    }

}

package com.example.android.androidNotes;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {

    public TextView title;
    public TextView des;
    public TextView time;


    public MyViewHolder(View view)
    {
        super(view);
        title = view.findViewById(R.id.titleNotebox);
        time = view.findViewById(R.id.timeNoteEdit);
        des = view.findViewById(R.id.noteDecription);

    }
}

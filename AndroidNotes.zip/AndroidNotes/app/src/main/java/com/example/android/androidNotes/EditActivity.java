package com.example.android.androidNotes;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;

public class EditActivity extends AppCompatActivity {

    private static final String TAG = "EditActivity";
    private EditText noteTitleView;
    private EditText noteDescriptionView;
    private int positionOfNote;
    private boolean noteExists;
    private String presentTitle = "";
    private String presentDescription = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
        noteTitleView = findViewById(R.id.editTextBox);
        noteDescriptionView = findViewById(R.id.editTextMultiText);
        noteDescriptionView.setMovementMethod(new ScrollingMovementMethod());

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("isExistingNote")) {

            noteExists = intent.getBooleanExtra("isExistingNote", false);
            if (noteExists) {

                Notes exitingNote = (Notes) intent.getSerializableExtra("existingNote");
                positionOfNote = intent.getIntExtra("existingNotePosition", 0);
                if (exitingNote != null) {

                    presentTitle = exitingNote.getNoteTitle();
                    presentDescription = exitingNote.getNoteDescription();
                    noteTitleView.setText(presentTitle);
                    noteDescriptionView.setText(presentDescription);
                }
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.saveItemEdit) {
            checkandSave(false);
            return true;
        } else {

            return super.onOptionsItemSelected(item);
        }
    }

    private void checkandSave(boolean backButtonPressed) {

        String title = noteTitleView.getText().toString();
        String description = noteDescriptionView.getText().toString();
        if (noteExists) {

            if (!TextUtils.isEmpty(title)) {

                boolean ifTitleChanged = !TextUtils.isEmpty(title) &&
                        !TextUtils.isEmpty(presentTitle) &&
                        !TextUtils.equals(title, presentTitle);

                if (ifTitleChanged || !TextUtils.equals(description, presentDescription)) {
                    if (backButtonPressed) {
                        confirmationDialog(false);
                    } else {
                        saveExistingNote();
                    }
                } else {
                    exitActivity();
                }
            } else {
                Toast.makeText(this, "Title is not entered", Toast.LENGTH_SHORT).show();
                exitActivity();
            }

        } else {
            if (!TextUtils.isEmpty(title)) {
                if (backButtonPressed) {
                    confirmationDialog(true);
                } else {
                    saveNote();
                    Toast.makeText(this, "New Note Added", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Title is not entered", Toast.LENGTH_SHORT).show();
                exitActivity();
            }
        }
    }

    public void exitActivity() {

        Intent dataIntent = new Intent();
        dataIntent.putExtra("noteChanged", false);
        setResult(RESULT_OK, dataIntent);
        finish();
    }

    private void saveExistingNote() {
        String title = noteTitleView.getText().toString();
        String description = noteDescriptionView.getText().toString();
        Intent dataIntent = new Intent();
        Notes existingNote = new Notes(title, description, new Date());
        dataIntent.putExtra("existingNote", existingNote);
        dataIntent.putExtra("existingNotePosition", positionOfNote);
        dataIntent.putExtra("noteChanged", true);
        setResult(RESULT_OK, dataIntent);
        finish();
    }

    private void saveNote() {
        String title = noteTitleView.getText().toString();
        String description = noteDescriptionView.getText().toString();
        Intent dataIntent = new Intent();
        Notes newNote = new Notes(title, description, new Date());
        dataIntent.putExtra("newNote", newNote);
        setResult(RESULT_OK, dataIntent);
        finish();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        Log.d(TAG, "onSaveInstanceState: ");
        outState.putInt("existingNotePosition", positionOfNote);
        outState.putBoolean("isExistingNote", noteExists);
        outState.putString("existingNoteTitle", presentTitle);
        outState.putString("existingNoteDescription", presentDescription);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedState) {
        Log.d(TAG, "onRestoreInstanceState: ");
        super.onRestoreInstanceState(savedState);
        positionOfNote = savedState.getInt("existingNotePosition");
        noteExists = savedState.getBoolean("isExistingNote");
        presentTitle = savedState.getString("existingNoteTitle");
        presentDescription = savedState.getString("existingNoteDescription");
    }


    @Override
    public void onBackPressed() {
        checkandSave(true);
    }

    public void confirmationDialog(final boolean newNote) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        String titleEntered = noteTitleView.getText().toString();

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                if (newNote) {
                    saveNote();
                } else {
                    saveExistingNote();
                }
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                exitActivity();
            }
        });
        builder.setMessage("Your note is not saved!\nSave note '" + titleEntered + "'?");
        AlertDialog dialog = builder.create();
        dialog.show();
    }

}
